﻿namespace _201811527_patent
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.allbutton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.panel38 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel39 = new System.Windows.Forms.Panel();
            this.search = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.Search_Term1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.checkedListBox2 = new System.Windows.Forms.CheckedListBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.tabControl1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.panel28.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel18.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabControl1.ItemSize = new System.Drawing.Size(133, 40);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(777, 676);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage6.Controls.Add(this.textBox6);
            this.tabPage6.Controls.Add(this.allbutton);
            this.tabPage6.Controls.Add(this.dataGridView1);
            this.tabPage6.Controls.Add(this.panel26);
            this.tabPage6.Controls.Add(this.panel27);
            this.tabPage6.Location = new System.Drawing.Point(4, 44);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(769, 628);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "전체특허조회";
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox6.Location = new System.Drawing.Point(238, 150);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(468, 15);
            this.textBox6.TabIndex = 21;
            this.textBox6.Text = "\'전체 특허 조회\' 클릭 후 원하는 특허를 클릭하면 해당 특허의 정보를 볼 수 있습니다.";
            // 
            // allbutton
            // 
            this.allbutton.BackColor = System.Drawing.Color.SteelBlue;
            this.allbutton.Font = new System.Drawing.Font("배달의민족 주아", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.allbutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.allbutton.Location = new System.Drawing.Point(30, 134);
            this.allbutton.Name = "allbutton";
            this.allbutton.Size = new System.Drawing.Size(188, 49);
            this.allbutton.TabIndex = 20;
            this.allbutton.Text = "전체 특허 조회";
            this.allbutton.UseVisualStyleBackColor = false;
            this.allbutton.Click += new System.EventHandler(this.Allbutton_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.Location = new System.Drawing.Point(30, 203);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 40;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(706, 397);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DataGridView1_RowHeaderMouseClick);
            // 
            // panel26
            // 
            this.panel26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel26.BackgroundImage")));
            this.panel26.Location = new System.Drawing.Point(275, 21);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(283, 88);
            this.panel26.TabIndex = 8;
            // 
            // panel27
            // 
            this.panel27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel27.BackgroundImage")));
            this.panel27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel27.Location = new System.Drawing.Point(179, 27);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(82, 75);
            this.panel27.TabIndex = 7;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage7.Controls.Add(this.panel12);
            this.tabPage7.Controls.Add(this.button8);
            this.tabPage7.Controls.Add(this.panel1);
            this.tabPage7.Controls.Add(this.button5);
            this.tabPage7.Controls.Add(this.panel29);
            this.tabPage7.Controls.Add(this.panel28);
            this.tabPage7.Controls.Add(this.comboBox1);
            this.tabPage7.Controls.Add(this.checkedListBox1);
            this.tabPage7.Controls.Add(this.panel38);
            this.tabPage7.Controls.Add(this.label22);
            this.tabPage7.Controls.Add(this.panel39);
            this.tabPage7.Controls.Add(this.search);
            this.tabPage7.Controls.Add(this.button10);
            this.tabPage7.Location = new System.Drawing.Point(4, 44);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(769, 628);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "특허 검색";
            // 
            // panel12
            // 
            this.panel12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel12.BackgroundImage")));
            this.panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel12.Location = new System.Drawing.Point(660, 40);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(45, 39);
            this.panel12.TabIndex = 20;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FloralWhite;
            this.button8.Font = new System.Drawing.Font("배달의민족 주아", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button8.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.button8.Location = new System.Drawing.Point(624, 85);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(81, 34);
            this.button8.TabIndex = 5;
            this.button8.Text = "사용 방법";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(676, 514);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(48, 54);
            this.panel1.TabIndex = 19;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.SteelBlue;
            this.button5.Font = new System.Drawing.Font("나눔고딕 ExtraBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button5.Location = new System.Drawing.Point(676, 574);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(83, 38);
            this.button5.TabIndex = 18;
            this.button5.Text = "SAVE";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Button5_Click_1);
            // 
            // panel29
            // 
            this.panel29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel29.BackgroundImage")));
            this.panel29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel29.Location = new System.Drawing.Point(57, 230);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(273, 50);
            this.panel29.TabIndex = 17;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel28.Controls.Add(this.textBox12);
            this.panel28.Controls.Add(this.label27);
            this.panel28.Controls.Add(this.textBox9);
            this.panel28.Controls.Add(this.label26);
            this.panel28.Controls.Add(this.textBox11);
            this.panel28.Controls.Add(this.textBox7);
            this.panel28.Controls.Add(this.label25);
            this.panel28.Controls.Add(this.textBox10);
            this.panel28.Controls.Add(this.label24);
            this.panel28.Controls.Add(this.label23);
            this.panel28.Controls.Add(this.textBox8);
            this.panel28.Controls.Add(this.label21);
            this.panel28.Location = new System.Drawing.Point(343, 239);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(327, 373);
            this.panel28.TabIndex = 16;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(9, 189);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox12.Size = new System.Drawing.Size(303, 64);
            this.textBox12.TabIndex = 20;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label27.Location = new System.Drawing.Point(8, 171);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(56, 15);
            this.label27.TabIndex = 19;
            this.label27.Text = "abstract";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(9, 138);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox9.Size = new System.Drawing.Size(301, 30);
            this.textBox9.TabIndex = 18;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label26.Location = new System.Drawing.Point(6, 12);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 15);
            this.label26.TabIndex = 6;
            this.label26.Text = "app_num";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(9, 30);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(301, 30);
            this.textBox11.TabIndex = 2;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(9, 325);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox7.Size = new System.Drawing.Size(301, 30);
            this.textBox7.TabIndex = 14;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label25.Location = new System.Drawing.Point(6, 67);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(64, 15);
            this.label25.TabIndex = 7;
            this.label25.Text = "app_date";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(9, 85);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(301, 30);
            this.textBox10.TabIndex = 8;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.Location = new System.Drawing.Point(6, 120);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(30, 15);
            this.label24.TabIndex = 17;
            this.label24.Text = "title";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.Location = new System.Drawing.Point(6, 256);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(63, 15);
            this.label23.TabIndex = 11;
            this.label23.Text = "inventors";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(9, 273);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox8.Size = new System.Drawing.Size(301, 30);
            this.textBox8.TabIndex = 12;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label21.Location = new System.Drawing.Point(6, 308);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(39, 15);
            this.label21.TabIndex = 13;
            this.label21.Text = "CPCs";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox1.Font = new System.Drawing.Font("나눔고딕 ExtraBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.comboBox1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "제목",
            "발명자",
            "번호",
            "초록"});
            this.comboBox1.Location = new System.Drawing.Point(57, 146);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(113, 23);
            this.comboBox1.TabIndex = 15;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(57, 287);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.ScrollAlwaysVisible = true;
            this.checkedListBox1.Size = new System.Drawing.Size(273, 327);
            this.checkedListBox1.TabIndex = 5;
            this.checkedListBox1.Click += new System.EventHandler(this.CheckedListBox1_Click_1);
            // 
            // panel38
            // 
            this.panel38.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel38.BackgroundImage")));
            this.panel38.Location = new System.Drawing.Point(287, 16);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(283, 88);
            this.panel38.TabIndex = 14;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("나눔고딕 ExtraBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label22.Location = new System.Drawing.Point(244, 117);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(279, 15);
            this.label22.TabIndex = 11;
            this.label22.Text = "검색창에 검색어를 입력하고 검색을 클릭해주세요.";
            // 
            // panel39
            // 
            this.panel39.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel39.BackgroundImage")));
            this.panel39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel39.Location = new System.Drawing.Point(199, 29);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(82, 75);
            this.panel39.TabIndex = 13;
            // 
            // search
            // 
            this.search.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.search.Font = new System.Drawing.Font("나눔고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.search.ForeColor = System.Drawing.SystemColors.WindowText;
            this.search.Location = new System.Drawing.Point(57, 175);
            this.search.Multiline = true;
            this.search.Name = "search";
            this.search.ShortcutsEnabled = false;
            this.search.Size = new System.Drawing.Size(561, 25);
            this.search.TabIndex = 10;
            this.search.Text = "검색어를 입력해주세요.";
            this.search.Click += new System.EventHandler(this.Search_Click_1);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.DimGray;
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button10.Font = new System.Drawing.Font("나눔고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button10.Location = new System.Drawing.Point(624, 173);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(81, 30);
            this.button10.TabIndex = 12;
            this.button10.Text = "검색";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.Button10_Click_1);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.panel30);
            this.tabPage1.Controls.Add(this.panel25);
            this.tabPage1.Controls.Add(this.panel20);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.panel14);
            this.tabPage1.Controls.Add(this.panel23);
            this.tabPage1.Controls.Add(this.panel24);
            this.tabPage1.Controls.Add(this.panel10);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.panel11);
            this.tabPage1.Controls.Add(this.panel13);
            this.tabPage1.Controls.Add(this.panel8);
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.Search_Term1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Font = new System.Drawing.Font("나눔고딕 ExtraBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabPage1.Location = new System.Drawing.Point(4, 44);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(769, 628);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "복합 검색";
            // 
            // panel30
            // 
            this.panel30.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel30.BackgroundImage")));
            this.panel30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel30.Location = new System.Drawing.Point(39, 338);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(96, 28);
            this.panel30.TabIndex = 16;
            // 
            // panel25
            // 
            this.panel25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel25.BackgroundImage")));
            this.panel25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel25.Location = new System.Drawing.Point(44, 177);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(216, 63);
            this.panel25.TabIndex = 15;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.AliceBlue;
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.panel21);
            this.panel20.Controls.Add(this.panel22);
            this.panel20.Controls.Add(this.label8);
            this.panel20.Location = new System.Drawing.Point(44, 453);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(290, 71);
            this.panel20.TabIndex = 13;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.SlateGray;
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Location = new System.Drawing.Point(289, 31);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(309, 30);
            this.panel21.TabIndex = 6;
            // 
            // panel22
            // 
            this.panel22.Location = new System.Drawing.Point(289, 31);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(301, 30);
            this.panel22.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(20, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(246, 28);
            this.label8.TabIndex = 5;
            this.label8.Text = "! 검색결과에 포함되지 않아야 하는 단어\r\n(포함되어야하는단어 ! 포함되지않아야하는단어)";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.AliceBlue;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(44, 382);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(290, 71);
            this.panel3.TabIndex = 10;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SlateGray;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Location = new System.Drawing.Point(289, 31);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(309, 30);
            this.panel4.TabIndex = 6;
            // 
            // panel9
            // 
            this.panel9.Location = new System.Drawing.Point(289, 31);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(301, 30);
            this.panel9.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(31, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(226, 28);
            this.label4.TabIndex = 5;
            this.label4.Text = "# 검색결과에 포함되어야 하는 단어\r\n(포함되어야하는단어 # 포함되어야하는단어)";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel14
            // 
            this.panel14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel14.BackgroundImage")));
            this.panel14.Location = new System.Drawing.Point(290, 54);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(283, 88);
            this.panel14.TabIndex = 6;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.label10);
            this.panel23.Location = new System.Drawing.Point(334, 453);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(390, 37);
            this.panel23.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(83, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(217, 14);
            this.label10.TabIndex = 0;
            this.label10.Text = "\'자동차\'관련 특허 중 \'엔진\' 관련 특허 제거";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel24.Controls.Add(this.label11);
            this.panel24.Location = new System.Drawing.Point(334, 485);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(390, 39);
            this.panel24.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label11.Location = new System.Drawing.Point(114, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(141, 14);
            this.label11.TabIndex = 6;
            this.label11.Text = "검색식 예시 : 자동차 ! 엔진";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel10.Controls.Add(this.label5);
            this.panel10.Location = new System.Drawing.Point(334, 418);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(390, 35);
            this.panel10.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label5.Location = new System.Drawing.Point(114, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 14);
            this.label5.TabIndex = 6;
            this.label5.Text = "검색식 예시 : 자동차 # 엔진";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("나눔고딕 ExtraBold", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(257, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 14);
            this.label1.TabIndex = 1;
            this.label1.Text = "검색창에 검색어를 입력하고 검색을 클릭해주세요.";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.label7);
            this.panel11.Location = new System.Drawing.Point(334, 382);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(390, 40);
            this.panel11.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(92, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(192, 14);
            this.label7.TabIndex = 0;
            this.label7.Text = "\'자동차\'관련 특허 중 \'엔진\' 관련 특허";
            // 
            // panel13
            // 
            this.panel13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel13.BackgroundImage")));
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel13.Location = new System.Drawing.Point(194, 60);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(82, 75);
            this.panel13.TabIndex = 4;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel8.Controls.Add(this.label9);
            this.panel8.Location = new System.Drawing.Point(334, 276);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(390, 35);
            this.panel8.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label9.Location = new System.Drawing.Point(114, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(154, 14);
            this.label9.TabIndex = 6;
            this.label9.Text = "검색식 예시 : 자동차 * 이영은";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label6);
            this.panel5.Location = new System.Drawing.Point(334, 240);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(390, 40);
            this.panel5.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(61, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(272, 14);
            this.label6.TabIndex = 0;
            this.label6.Text = "\'이영은\'이 발명한 \'자동차\'관련 특허를 찾고 싶은 경우";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.AliceBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(44, 240);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(290, 71);
            this.panel2.TabIndex = 4;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.SlateGray;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Location = new System.Drawing.Point(289, 31);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(309, 30);
            this.panel7.TabIndex = 6;
            // 
            // panel6
            // 
            this.panel6.Location = new System.Drawing.Point(289, 31);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(301, 30);
            this.panel6.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(41, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(208, 28);
            this.label3.TabIndex = 5;
            this.label3.Text = "* 특정 발명자가 발명한 특허를 찾는 경우\r\n(특허 * 발명자)";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Search_Term1
            // 
            this.Search_Term1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Search_Term1.Font = new System.Drawing.Font("나눔고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Search_Term1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Search_Term1.Location = new System.Drawing.Point(44, 559);
            this.Search_Term1.Multiline = true;
            this.Search_Term1.Name = "Search_Term1";
            this.Search_Term1.Size = new System.Drawing.Size(591, 25);
            this.Search_Term1.TabIndex = 0;
            this.Search_Term1.Text = "검색어를 입력해주세요.";
            this.Search_Term1.Click += new System.EventHandler(this.Search_Term1_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DimGray;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Font = new System.Drawing.Font("나눔고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(643, 556);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 30);
            this.button1.TabIndex = 2;
            this.button1.Text = "검색";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Button1_Click_1);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage5.Controls.Add(this.checkedListBox2);
            this.tabPage5.Controls.Add(this.button6);
            this.tabPage5.Controls.Add(this.button3);
            this.tabPage5.Controls.Add(this.panel19);
            this.tabPage5.Controls.Add(this.panel18);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Controls.Add(this.panel17);
            this.tabPage5.Controls.Add(this.panel16);
            this.tabPage5.Controls.Add(this.panel15);
            this.tabPage5.Location = new System.Drawing.Point(4, 44);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(769, 628);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "특허보관";
            // 
            // checkedListBox2
            // 
            this.checkedListBox2.FormattingEnabled = true;
            this.checkedListBox2.Location = new System.Drawing.Point(28, 150);
            this.checkedListBox2.Name = "checkedListBox2";
            this.checkedListBox2.Size = new System.Drawing.Size(305, 378);
            this.checkedListBox2.TabIndex = 12;
            this.checkedListBox2.Click += new System.EventHandler(this.CheckedListBox2_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.SlateGray;
            this.button6.Font = new System.Drawing.Font("나눔고딕 ExtraBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.Location = new System.Drawing.Point(416, 584);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(118, 44);
            this.button6.TabIndex = 11;
            this.button6.Text = "DELETE ALL";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightSlateGray;
            this.button3.Font = new System.Drawing.Font("나눔고딕 ExtraBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.ForeColor = System.Drawing.SystemColors.Control;
            this.button3.Location = new System.Drawing.Point(603, 561);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(118, 44);
            this.button3.TabIndex = 9;
            this.button3.Text = "SAVE";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // panel19
            // 
            this.panel19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel19.BackgroundImage")));
            this.panel19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel19.Location = new System.Drawing.Point(552, 559);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(46, 45);
            this.panel19.TabIndex = 8;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel18.Controls.Add(this.textBox13);
            this.panel18.Controls.Add(this.label2);
            this.panel18.Controls.Add(this.textBox5);
            this.panel18.Controls.Add(this.label16);
            this.panel18.Controls.Add(this.textBox4);
            this.panel18.Controls.Add(this.label15);
            this.panel18.Controls.Add(this.textBox3);
            this.panel18.Controls.Add(this.label14);
            this.panel18.Controls.Add(this.textBox2);
            this.panel18.Controls.Add(this.label13);
            this.panel18.Controls.Add(this.label12);
            this.panel18.Controls.Add(this.textBox1);
            this.panel18.Location = new System.Drawing.Point(358, 150);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(363, 377);
            this.panel18.TabIndex = 7;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(18, 188);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox13.Size = new System.Drawing.Size(319, 67);
            this.textBox13.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(15, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 15);
            this.label2.TabIndex = 15;
            this.label2.Text = "abstract";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(18, 327);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(319, 30);
            this.textBox5.TabIndex = 14;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.Location = new System.Drawing.Point(17, 309);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 15);
            this.label16.TabIndex = 13;
            this.label16.Text = "CPCs";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(18, 276);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox4.Size = new System.Drawing.Size(319, 30);
            this.textBox4.TabIndex = 12;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.Location = new System.Drawing.Point(18, 258);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 15);
            this.label15.TabIndex = 11;
            this.label15.Text = "inventors";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(18, 137);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox3.Size = new System.Drawing.Size(319, 30);
            this.textBox3.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.Location = new System.Drawing.Point(17, 119);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 15);
            this.label14.TabIndex = 9;
            this.label14.Text = "title";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(18, 86);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(319, 30);
            this.textBox2.TabIndex = 8;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(17, 67);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 15);
            this.label13.TabIndex = 7;
            this.label13.Text = "app_date";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.Location = new System.Drawing.Point(15, 8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 15);
            this.label12.TabIndex = 6;
            this.label12.Text = "app_num";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(18, 33);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(319, 30);
            this.textBox1.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SteelBlue;
            this.button2.Font = new System.Drawing.Font("나눔고딕 ExtraBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(416, 535);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 44);
            this.button2.TabIndex = 5;
            this.button2.Text = "DELETE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // panel17
            // 
            this.panel17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel17.BackgroundImage")));
            this.panel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel17.Location = new System.Drawing.Point(28, 32);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(72, 80);
            this.panel17.TabIndex = 4;
            // 
            // panel16
            // 
            this.panel16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel16.BackgroundImage")));
            this.panel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel16.Location = new System.Drawing.Point(360, 559);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(50, 45);
            this.panel16.TabIndex = 3;
            // 
            // panel15
            // 
            this.panel15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel15.BackgroundImage")));
            this.panel15.Location = new System.Drawing.Point(100, 31);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(283, 85);
            this.panel15.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(777, 676);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "특허 검색";
            this.tabControl1.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button allbutton;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel28;
        public System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label27;
        public System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label26;
        public System.Windows.Forms.TextBox textBox11;
        public System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label25;
        public System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        public System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.TextBox search;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Search_Term1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage5;
        public System.Windows.Forms.CheckedListBox checkedListBox2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel18;
        public System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label16;
        public System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label14;
        public System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel15;
    }
}

